#by @K1p1k#
#Downloaded from TG @KiTools#
#Leave this inscription#

from .user_start import dp
from .admin_menu import dp
from .admin_func import dp
from .admin_func_callback import dp
from .user_get_films import dp
from .user_search_kino import dp
from .user_func import dp
from .user_func_callback import dp  
__all__=['dp']

#Автор: @K1p1k#
#Загружено с TG @KiTools#
#Оставь эту надпись#