﻿

token='5468861352:AAHDRuamIEm0HM-2Gf3UfLZz-VMtJmsGK78 ' #https://t.me/BotFather
admin_id=[819248865] #https://t.me/getidsbot #водить через запетую если не сколько [12321, 3139231]
rate_searsh=10
