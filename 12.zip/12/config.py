#By @K1p1k#
#Downloaded from TG @KiTools#
#Leave this inscription#

token='5876565568:AAGlnMNsImc9vaXLtaSp0I5q1u282xlvv_k' #https://t.me/BotFather
admin_id=int(5480642013) #https://t.me/getidsbot

#Автор: @K1p1k#
#Загружено с TG @KiTools#
#Оставь эту надпись#